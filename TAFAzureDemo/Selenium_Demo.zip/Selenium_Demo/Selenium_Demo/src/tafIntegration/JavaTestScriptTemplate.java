package tafIntegration;

public class JavaTestScriptTemplate extends tafIntegration.JavaScriptSuperClass {
	/**
	 * @testpro app="" action="" description=""
	 * @since
	 * @author
	 */
	public void execute() {
		try {

		} catch (Exception ex) {

			logStoreException(ex);

		} finally {

		}

	}
}